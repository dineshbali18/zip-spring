package com.example.bookings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
